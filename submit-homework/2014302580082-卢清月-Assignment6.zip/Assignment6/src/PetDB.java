import java.sql.DriverManager;


import java.sql.ResultSet;
import java.util.ArrayList;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class PetDB {
	
	 private ResultSet res;
	 private Statement stmt;
	 private Connection conn;
     private int id;
	 private String name,eat,drink,live;
	 private String hobby,price;
	
    public void getConnection(String URL,String User,String Password){
        try
        {
         //ע��SQL Server JDBC��������
         String driver = "com.microsoft.jdbc.sqlserver.SQLServerDriver";
         Class.forName(driver);
       //���ӵ�ָ�����ݿ��URL
         URL = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456 ";
         User ="root";  
         Password = "123456";  
         //ʹ�� DriverManager ��� getConnection ���������ݿ��������
         conn = (Connection) DriverManager.getConnection(URL,User,Password);      
         stmt=(Statement) conn.createStatement();
         System.out.print("ok!");
        } catch (Exception e) {
            System.out.print("�޷����ӣ�");
        }
    }


	public boolean close() {
	    try {
            res.close();
            stmt.close();
            conn.close();
            return true;
        } catch (Exception e) {
            System.out.print("ʧ�ܣ�");
            return false;
        }
	}


	public boolean query(Object keyword) {
		try{
			String sql2 = "SELECT id,name,eat,drink,live,hobby,price FROM 20144302580082_pet WHERE id = '" + keyword + "'";
		    res = stmt.executeQuery(sql2);
		    while (res.next()) {
		    	id = res.getInt("id");
                name = res.getString("name");
                eat = res.getString("eat");
                drink = res.getString("drink");
                live = res.getString("live");
                hobby = res.getString("hobby");
                price = res.getString("price");
        	    Pet mypet = new Pet(id,name,eat,drink,live,hobby,price);
        	    ArrayList<Pet> petinfo = new ArrayList<Pet>();
        	    petinfo.add(mypet);
            }
          
		}catch(Exception e){
			System.out.print("��ѯʧ��!");
		}
		return false;
}



}
