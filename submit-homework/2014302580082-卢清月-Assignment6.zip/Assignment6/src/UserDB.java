import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.*;


public class UserDB  {
	 LoginGUI l = new LoginGUI();
	 private ResultSet res;
	 private Statement stmt;
	 private Connection conn;
     public void getConnection(String URL,String User,String Password){
         try
         {
          //ע��SQL Server JDBC��������
          String driver = "com.microsoft.jdbc.sqlserver.SQLServerDriver";
          Class.forName(driver);
        //���ӵ�ָ�����ݿ��URL
          URL = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456 ";
          User ="root";  
          Password = "123456";  
          //ʹ�� DriverManager ��� getConnection ���������ݿ��������
          conn = (Connection) DriverManager.getConnection(URL,User,Password);      
          stmt=(Statement) conn.createStatement();
         } catch (Exception e) {
             System.out.print("�޷����ӣ�");
         }
     }

	public boolean insert(String... args) {
		try{
		String sql1="insert into 2014302580082_user (user,password) values('"+l.user+"','"+l.password+"')";
		stmt.executeUpdate(sql1);
		return false;
		}catch(Exception e){
			System.out.println("����ʧ�ܣ�");
			return false;
		}
	}

	public boolean close() {
	    try {
            res.close();
            stmt.close();
            conn.close();
            return true;
        } catch (Exception e) {
            System.out.print("ʧ�ܣ�");
            return false;
        }
	}
	
	public boolean delete(String id) {
		
		return false;
	}

	public boolean query(Object keyword) {
		try{
		String sql2 = "select user,password��from��2014302580082_user��where user='"+l.user+"'and password='"+l.password+"'";
		res = stmt.executeQuery(sql2);
		return res.next();
	}catch(Exception e){
		System.out.println("û�в�ѯ���!");
		return false;
	}
	}
//�û���¼��֤
@SuppressWarnings("null")
public int authenticateUser (String user,String password) throws SQLException
  {
    ResultSet res=null;
    int i=0;
   
    try{
    	String sql1="insert into 2014302580082_user (user,password) values('"+l.user+"','"+l.password+"')";
		stmt.executeUpdate(sql1);

	    while(res.next()){
	    	if(res.getString("user").equals(user) && res.getString("password").equals(password)){
	    		i=1;
	    	}
        }
    	}catch (Exception e) {
		System.out.println("��֤ʧ�ܣ�");
    	}
	return i;


  }
}

