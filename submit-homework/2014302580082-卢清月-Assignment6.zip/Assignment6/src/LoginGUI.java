import java.awt.HeadlessException;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.*;

@SuppressWarnings("serial")
public class LoginGUI extends JFrame {
	    public String user;
	    public String password;
		private JLabel jl1 = new JLabel("�˺�");
		private JLabel jl2 = new JLabel("����");
		private JTextField jtf1 = new JTextField();
		private JTextField jtf2 = new JTextField();
		private JButton jb1 = new JButton("��½");
		private JButton jb2 = new JButton("ע��");
		
		public LoginGUI (){
			JFrame jf1 = new JFrame();
			//���ô���
			this.setResizable(false);
			this.setTitle("��½�����̵�");
            this.setBounds(200,200,350,280);			
            this.setVisible(true);
            setLayout(null);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			jl1.setBounds(70,50,50,30);
			add(jl1);
			jl2.setBounds(70,100,50,30);
			add(jl2);
			//��ʼ�������
            jtf1.setOpaque(true);
            jtf2.setOpaque(true);
            jtf1.setEditable(true);
            jtf2.setEditable(true);
            jtf1.setBounds(120,50,150,30);
            jtf2.setBounds(120,100,150,30);
            add(jtf1);
            add(jtf2);
			jb1.setBounds(80,170,80,40);
            jb2.setBounds(180,170,80,40);
            
			//��ת��ע�����
			jb2.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					jf1.setVisible(false);
					JFrame jf2 = new JFrame("ע��");				
					jf2.setBounds(300,100,400,500);
					jf2.setVisible(true);
					jf2.setLayout(null);
				    JLabel l1 = new JLabel("�����˺�");
					JLabel l2 = new JLabel("��������");
					JLabel l3 = new JLabel("ȷ������");
					JTextField tf1 = new JTextField();
					JTextField tf2 = new JTextField();
					JTextField tf3 = new JTextField();
					JButton b1 = new JButton("ȷ��ע��");
					l1.setBounds(70,70,80,30);
					l2.setBounds(70,120,80,30);
					l3.setBounds(70,170,80,30);
					tf1.setBounds(160,70,150,30);
					tf2.setBounds(160,120,150,30);
					tf3.setBounds(160, 170,150, 30);
					tf1.setOpaque(true); tf2.setOpaque(true); tf3.setOpaque(true);
					tf1.setEditable(true);  tf2.setEditable(true);  tf3.setEditable(true);
					jf2.add(l1); jf2.add(l2); jf2.add(l3); jf2.add(tf1); jf2.add(tf2); jf2.add(tf3);
					b1.setBounds(150,250,100,50);
					b1.addActionListener(new ActionListener(){
						public void actionPerformed(ActionEvent e) {
							 user = tf1.getText();
							 password = tf2.getText();
							String password1 = tf3.getText();
							if(user.equals("")||password.equals("")||password1.equals("")){
								JOptionPane.showMessageDialog(null, "����Ϊ��!");
							}
							else if(!password.equals(password1)){
								JOptionPane.showMessageDialog(null, "�����������벻һ��!");
							}
							else {
								JOptionPane.showMessageDialog(null, "ע��ɹ�!");
							}						
						}					
					});				
					jf2.add(b1);
				}
			});	
			add(jb2);
			
			//��ת����½�����
			jb1.addActionListener(new ActionListener(){
		       
				public void actionPerformed(ActionEvent e){
				      UserDB u = new UserDB() ;
				      u.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema","root","123456");
					try {
						if(u.authenticateUser(user, password)>=0){
						@SuppressWarnings("unused")
						ShopGUI shopgui= new ShopGUI();
						}
						else{
							JOptionPane.showMessageDialog(null, "��½ʧ��!");
						}
					} catch (HeadlessException e1) {
						e1.printStackTrace();
					} catch (SQLException e1) {
	
						e1.printStackTrace();
					}
				}
			});
            add(jb1);
		}
		 public static void main(String[] args) {
	    	  @SuppressWarnings("unused")
			LoginGUI logingui = new LoginGUI();
	      }

}
