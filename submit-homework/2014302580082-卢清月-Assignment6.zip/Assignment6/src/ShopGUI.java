import java.awt.Container;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;

import java.awt.event.MouseListener;


import javax.swing.*;

@SuppressWarnings("serial")
public class ShopGUI extends JFrame{
	private JFrame mycart;
	private JPanel jp1;
	public int id;
	public String name;
	public String eat;
	public String drink;
	public String live;
	public String hobby;
	public String price;
	private JLabel dog,cat,turtle,parrot,hamster,squirrel,rabbit,snake,lizard,fish,myna,canary ;
	private JLabel jlabel = new JLabel("����������������");
	private JButton gm1= new JButton("����"),gm2= new JButton("����"),gm3= new JButton("����"),gm4= new JButton("����"),
			gm5= new JButton("����"),gm6= new JButton("����"),gm7= new JButton("����"),gm8= new JButton("����"),
			gm9= new JButton("����"),gm10= new JButton("����"),gm11= new JButton("����"),gm12= new JButton("����"),
			cart = new JButton("�鿴���ﳵ") ;
	PetDB petdb = new PetDB();
	
       public ShopGUI(){
    	   JFrame shop = new JFrame(); 
    	   JPanel jp = new JPanel(); 
			Container content=this.getContentPane();
			jp.setLayout(null);              
            content.add(jp);
			//���ô���
			this.setResizable(false);
			this.setTitle("�����̵�");
            this.setBounds(120,100,750,460);			
            this.setVisible(true);
            setLayout(null);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            jlabel.setBounds(270, 10, 300, 30);
            jlabel.setFont(new java.awt.Font("Dialog", 1, 20));
            jp.add(jlabel);
            //���ӳ�����Ϣ
            dog = new JLabel("dog"); 
            dog.setBounds(80,50,100,50); 
            dog.setFont(new java.awt.Font("Dialog", 1, 20));
            dog.addMouseListener(new MouseListener(){
            	public void mouseClicked(MouseEvent e) {
    		    JFrame dog = new JFrame();
    		    dog.setBounds(150,150,300,400);
    		    dog.setVisible(true);
				dog.setLayout(null);
			    JLabel doginfo = new JLabel(petdb.toString());
			    doginfo.setBounds(10,10,280,380);
			    dog.add(doginfo);
            }
				@Override
				public void mouseEntered(MouseEvent e) {
					
				}
				@Override
				public void mouseExited(MouseEvent e) {		
					
				}
				@Override
				public void mousePressed(MouseEvent e) {	
					
				}
				@Override
				public void mouseReleased(MouseEvent e) {	
					
				}		
				});   
            jp.add(dog);
            
            cat = new JLabel("cat"); 
            cat.setBounds(250,50,100,50);
            cat.setFont(new java.awt.Font("Dialog", 1, 20));
            cat.addMouseListener(new MouseListener(){
            	public void mouseClicked(MouseEvent e) {
            		JFrame cat = new JFrame();
            		cat.setBounds(150,150,300,400);
           		    cat.setVisible(true);
       				cat.setLayout(null);
       			    JLabel catinfo = new JLabel(petdb.toString());
    			    catinfo.setBounds(10,10,280,380);
    			    cat.add(catinfo);
            }
				@Override
				public void mouseEntered(MouseEvent e) {
					
				}
				@Override
				public void mouseExited(MouseEvent e) {		
					
				}
				@Override
				public void mousePressed(MouseEvent e) {	
					
				}
				@Override
				public void mouseReleased(MouseEvent e) {	
					
				}		
				});   
            jp.add(cat);
       
            turtle = new JLabel("turtle"); 
            turtle.setBounds(420,50,100,50);
            turtle.setFont(new java.awt.Font("Dialog", 1, 20));
            turtle.addMouseListener(new MouseListener(){
            	public void mouseClicked(MouseEvent e) {
            		JFrame turtle = new JFrame();
            		turtle.setBounds(150,150,300,400);
           		    turtle.setVisible(true);
       				turtle.setLayout(null);
       			    JLabel turtleinfo = new JLabel(petdb.toString());
    			    turtle.add(turtleinfo);
            }
				@Override
				public void mouseEntered(MouseEvent e) {
					
				}
				@Override
				public void mouseExited(MouseEvent e) {		
					
				}
				@Override
				public void mousePressed(MouseEvent e) {	
					
				}
				@Override
				public void mouseReleased(MouseEvent e) {	
					
				}		
				});   
            jp.add(turtle);
            
            parrot = new JLabel("parrot"); 
            parrot.setBounds(590,50,100,50);
            parrot.setFont(new java.awt.Font("Dialog", 1, 20));
            parrot.addMouseListener(new MouseListener(){
            	public void mouseClicked(MouseEvent e) {
            		JFrame parrot = new JFrame();
            		parrot.setBounds(150,150,300,400);
           		    parrot.setVisible(true);
       				parrot.setLayout(null);
       			    JLabel parrotinfo = new JLabel(petdb.toString());
    			    parrotinfo.setBounds(10,10,280,380);
    			    dog.add(parrotinfo);
            }
				@Override
				public void mouseEntered(MouseEvent e) {
					
				}
				@Override
				public void mouseExited(MouseEvent e) {		
					
				}
				@Override
				public void mousePressed(MouseEvent e) {	
					
				}
				@Override
				public void mouseReleased(MouseEvent e) {	
					
				}		
				});   
            jp.add(parrot);
            
            hamster = new JLabel("hamster"); 
            hamster.setBounds(80,150,100,50);
            hamster.setFont(new java.awt.Font("Dialog", 1, 20));
            hamster.addMouseListener(new MouseListener(){
            	public void mouseClicked(MouseEvent e) {
            		JFrame hamster = new JFrame();
            		hamster.setBounds(150,150,300,400);
           		    hamster.setVisible(true);
       				hamster.setLayout(null);
       			    JLabel hamsterinfo = new JLabel(petdb.toString());
    			    hamsterinfo.setBounds(10,10,280,380);
    			    hamster.add(hamsterinfo);
            }
				@Override
				public void mouseEntered(MouseEvent e) {
					
				}
				@Override
				public void mouseExited(MouseEvent e) {		
					
				}
				@Override
				public void mousePressed(MouseEvent e) {	
					
				}
				@Override
				public void mouseReleased(MouseEvent e) {	
					
				}		
				});   
            jp.add(hamster);
            
            squirrel = new JLabel("squirrel"); 
            squirrel.setBounds(250,150,100,50);
            squirrel.setFont(new java.awt.Font("Dialog", 1, 20));
            squirrel.addMouseListener(new MouseListener(){
            	public void mouseClicked(MouseEvent e) {
            		JFrame squirrel = new JFrame();
            		squirrel.setBounds(150,150,300,400);
           		    squirrel.setVisible(true);
       				squirrel.setLayout(null);
       			    JLabel squirrelinfo = new JLabel(petdb.toString());
    			    squirrelinfo.setBounds(10,10,280,380);
    			    squirrel.add(squirrelinfo);
            }
				@Override
				public void mouseEntered(MouseEvent e) {
					
				}
				@Override
				public void mouseExited(MouseEvent e) {		
					
				}
				@Override
				public void mousePressed(MouseEvent e) {	
					
				}
				@Override
				public void mouseReleased(MouseEvent e) {	
					
				}		
				});   
            jp.add(squirrel);
            
            rabbit = new JLabel("rabbit"); 
            rabbit.setBounds(420,150,100,50);
            rabbit.setFont(new java.awt.Font("Dialog", 1, 20));
            rabbit.addMouseListener(new MouseListener(){
            	public void mouseClicked(MouseEvent e) {
            		JFrame rabbit = new JFrame();
            		rabbit.setBounds(150,150,300,400);
            		rabbit.setVisible(true);
            		rabbit.setLayout(null);
            	    JLabel rabbitinfo = new JLabel(petdb.toString());
    			    rabbitinfo.setBounds(10,10,280,380);
    			    rabbit.add(rabbitinfo);
            }
				@Override
				public void mouseEntered(MouseEvent e) {
					
				}
				@Override
				public void mouseExited(MouseEvent e) {		
					
				}
				@Override
				public void mousePressed(MouseEvent e) {	
					
				}
				@Override
				public void mouseReleased(MouseEvent e) {	
					
				}		
				});   
            jp.add(rabbit);
            
            snake = new JLabel("snake"); 
            snake.setBounds(590,150,100,50);
            snake.setFont(new java.awt.Font("Dialog", 1, 20));
            snake.addMouseListener(new MouseListener(){
            	public void mouseClicked(MouseEvent e) {
            		JFrame snake = new JFrame();
            		snake.setBounds(150,150,300,400);
            		snake.setVisible(true);
            		snake.setLayout(null);
            	    JLabel snakeinfo = new JLabel(petdb.toString());
    			    snakeinfo.setBounds(10,10,280,380);
    			    snake.add(snakeinfo);
            }
				@Override
				public void mouseEntered(MouseEvent e) {
					
				}
				@Override
				public void mouseExited(MouseEvent e) {		
					
				}
				@Override
				public void mousePressed(MouseEvent e) {	
					
				}
				@Override
				public void mouseReleased(MouseEvent e) {	
					
				}		
				});   
            jp.add(snake);
            
            lizard = new JLabel("lizard"); 
            lizard.setBounds(80,260,100,50);
            lizard.setFont(new java.awt.Font("Dialog", 1, 20));
            lizard.addMouseListener(new MouseListener(){
            	public void mouseClicked(MouseEvent e) {
            		JFrame lizard = new JFrame();
            		lizard.setBounds(150,150,300,400);
            		lizard.setVisible(true);
            		lizard.setLayout(null);
            	    JLabel lizardinfo = new JLabel(petdb.toString());
    			    lizardinfo.setBounds(10,10,280,380);
    			    lizard.add(lizardinfo);
            }
				@Override
				public void mouseEntered(MouseEvent e) {
					
				}
				@Override
				public void mouseExited(MouseEvent e) {		
					
				}
				@Override
				public void mousePressed(MouseEvent e) {	
					
				}
				@Override
				public void mouseReleased(MouseEvent e) {	
					
				}		
				});   
            jp.add(lizard);
            
            fish = new JLabel("fish"); 
            fish.setBounds(250,260,100,50);
            fish.setFont(new java.awt.Font("Dialog", 1, 20));
            fish.addMouseListener(new MouseListener(){
            	public void mouseClicked(MouseEvent e) {
            		JFrame fish = new JFrame();
            		fish.setBounds(150,150,300,400);
            		fish.setVisible(true);
            		fish.setLayout(null);
            	    JLabel fishinfo = new JLabel(petdb.toString());
    			    fishinfo.setBounds(10,10,280,380);
    			    fish.add(fishinfo);
            }
				@Override
				public void mouseEntered(MouseEvent e) {
					
				}
				@Override
				public void mouseExited(MouseEvent e) {		
					
				}
				@Override
				public void mousePressed(MouseEvent e) {	
					
				}
				@Override
				public void mouseReleased(MouseEvent e) {	
					
				}		
				});   
            jp.add(fish);
            
            myna = new JLabel("myna"); 
            myna.setBounds(420,260,100,50);
            myna.setFont(new java.awt.Font("Dialog", 1, 20));
            myna.addMouseListener(new MouseListener(){
            	public void mouseClicked(MouseEvent e) {
            		JFrame myna = new JFrame();
            		myna.setBounds(150,150,300,400);
            		myna.setVisible(true);
            		myna.setLayout(null);
            	    JLabel mynainfo = new JLabel(petdb.toString());
    			    mynainfo.setBounds(10,10,280,380);
    			    myna.add(mynainfo);
            }
				@Override
				public void mouseEntered(MouseEvent e) {
					
				}
				@Override
				public void mouseExited(MouseEvent e) {		
					
				}
				@Override
				public void mousePressed(MouseEvent e) {	
					
				}
				@Override
				public void mouseReleased(MouseEvent e) {	
					
				}		
				});   
            jp.add(myna);
            
            canary = new JLabel("canary"); 
            canary.setBounds(590,260,100,50);
            canary.setFont(new java.awt.Font("Dialog", 1, 20));
            canary.addMouseListener(new MouseListener(){
            	public void mouseClicked(MouseEvent e) {
            		JFrame canary = new JFrame();
            		canary.setBounds(150,150,300,400);
            		canary.setVisible(true);
            		canary.setLayout(null);
            	    JLabel canaryinfo = new JLabel(petdb.toString());
    			    canaryinfo.setBounds(10,10,280,380);
    			    canary.add(canaryinfo);
            }
				@Override
				public void mouseEntered(MouseEvent e) {
					
				}
				@Override
				public void mouseExited(MouseEvent e) {		
					
				}
				@Override
				public void mousePressed(MouseEvent e) {	
					
				}
				@Override
				public void mouseReleased(MouseEvent e) {	
					
				}		
				});   
            jp.add(canary);
            gm1.setBounds(70,110,60,30); gm2.setBounds(240,110,60,30);gm3.setBounds(400,110,60,30);
            gm4.setBounds(580,110,60,30);gm5.setBounds(80,210,60,30);gm6.setBounds(240,210,60,30);
            gm7.setBounds(400,210,60,30);gm8.setBounds(580,210,60,30);gm9.setBounds(70,320,60,30);
            gm10.setBounds(240,320,60,30);gm11.setBounds(400,320,60,30);gm12.setBounds(580,320,60,30);
		    gm1.addActionListener(new ActionListener(){
				@Override
				public void actionPerformed(ActionEvent e) {
					jp1.add(dog);	
                    shop.setEnabled(false);
				}
            });
            jp.add(gm1); jp.add(gm2); jp.add(gm3); jp.add(gm4); jp.add(gm5); jp.add(gm6); 
            jp.add(gm7); jp.add(gm8); jp.add(gm9); jp.add(gm10); jp.add(gm11); jp.add(gm12); 

            //���ӹ��ﳵ��Ϣ
            cart.setBounds(280,380,150,40);
            cart.setFont(new java.awt.Font("Dialog", 1, 16));
            cart.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
					int amount = 0;
				    mycart = new JFrame();
				    JPanel jp1 = new JPanel(); 
					Container content1=mycart.getContentPane();
					jp1.setLayout(null);              
		            content1.add(jp1);
					mycart.setBounds(120,100,750,460);
					mycart.setVisible(true);
					mycart.setLayout(null);
				    mycart.setTitle("�ҵĹ��ﳵ");
				    JButton buy =new JButton("ȷ��֧��");
				    buy.addActionListener(new ActionListener(){
						@Override
						public void actionPerformed(ActionEvent arg0) {
							JOptionPane.showMessageDialog(null, "֧���ɹ�!");						
						}			    				    	
				    });
				    buy.setBounds(280,360,130,40);
				    jp1.add(buy);
				    JLabel myamount = new JLabel("�ܽ�"+amount);
				    myamount.setBounds(0,300,150,40);
				    jp1.add(myamount);
				}
            });
            jp.add(cart);
            
       }
}